const express =require('express');
const fs =require('fs');
const path  =require('path');
const app  = express();
const hbs =require( 'hbs');
const connection =require( './models/signUpRegistration.js');
var db = connection();

const port = process.env.PORT || 1800;
const homePath = path.join(__dirname, "../public/js");
const scrollPath = path.join("E:\\Project-2C", "../infiniteScrolling");
const static_path = path.join(__dirname, "../public/CSS");
const static_pathimage = path.join(__dirname, "../public/images");
const static_pathicon = path.join(__dirname, "../public/images/icon");
const template_path = path.join(__dirname, "../views");
const partial_path = path.join(__dirname, "../templates/partials");




// const static_path =path.join(__dirname,"../public/CSS");
// const static_pathimage =path.join(__dirname,"../public/images");
// const static_pathicon =path.join(__dirname,"../public/images/icon");
// const template_path =path.join(__dirname,"../template/views");
// const partial_path =path.join(__dirname,"../templates/partials");

app.use(express.json());

app.use(express.static(homePath));
app.use(express.static(static_path));
app.use(express.urlencoded({ extended: false }));

app.use(express.static(static_path));
app.use(express.static(static_path));

app.use(express.static(static_path));

app.use(express.static(static_pathimage));

app.use(express.static(static_pathicon));

app.set("view engine", "hbs");

app.set("views", template_path);

var email;
var pass;

app.get("/", (req, res) => {
  res.render("index");
});





// ------------------------------------------------when you want to login this code is responsible for that -----------------------------------------
app.post("/Homefinal", async (req, res) => {
  console.log("Post Method");
  var Name = req.body.signName;
  var Email = req.body.signEmail;
  var Pass = req.body.signPass;
  console.log(Name, Email, Pass);
  
  if (Name != "" && Email != "" && Pass != "") {
    var data = {
      Name: Name,
      email: Email,
      password: Pass

      // disabled the button sigup until it complete field of data
    }

    db.collection("customerSignUp").insertOne(data, function (err, collection) {
      if (err) throw err;
      console.log("Record inserted Successfully");
    });
    console.log("Sign Up Success.....");
    res.render("Homefinal");


  } 



  else {
    email = req.body.email;
    pass = req.body.pass;
    const valid = await db.collection("customerSignUp").findOne({ email: email });
    if (valid != null) {
      if (valid.email == email && valid.password == pass) {
             //const find = await db.collection("post").find().toArray(); 
           // console.log(find);
             //const DbData = JSON.stringify(find);
             //fs.writeFile('Data.json',DbData,()=>{});
             console.log("login success");
             res.render('Homefinal');
      } else {
        res.send("Invalid User Name and Password");
      }
    }
  }
});




var result;
app.get("/about", (req, res) => {
  res.render("about");
});

app.listen(port, () => {
  console.log(`server is running at ${port}`);
});
