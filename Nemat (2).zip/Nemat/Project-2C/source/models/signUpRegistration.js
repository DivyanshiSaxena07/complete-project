const express = require ('express');
const  bodyParser = require ('body-parser');
const mongoose = require ('mongoose');
var app=express();
//const connect = require('../db/connect.js')

var insert =()=>{
mongoose.connect('mongodb://127.0.0.1:27017/Homebuilder');
console.log("calling ");
return mongoose.connection;
}
module.exports = insert;

// db.collection('customerSignUp').insertOne(data,function(err,collection){
// 		if (err) throw err;
// 		console.log("Record inserted Successfully");	
// 	});
