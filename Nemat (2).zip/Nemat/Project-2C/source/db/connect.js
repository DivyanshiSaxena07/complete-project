const mongoose = require("mongoose");

module.exports = function(){
    mongoose.connect("mongodb://127.0.0.1:27017/Homebuilder",
    {
        useNewUrlParser:true,
        useUnifiedTopology:true, 
    }
        ).then(() =>{
        console.log("Connection Established");
    }).catch((err) => {
        console.log("Connection Failed");
    });
}

// const dbConnection = require('./mongodb');

// const insert =async ()=>{
//  const db =await dbConnection();
//  const result = await db.insertOne({
//     Name:"Ajay",
//     City:"Jhansi",
//     Age:21
//  });
//  if(result.acknowledged)
//  console.log("Data Inserted successfully");
//  else{
//     console.log("Data Not Inserted some Error find and resolve that error and run again");
//  }
// }
// insert();